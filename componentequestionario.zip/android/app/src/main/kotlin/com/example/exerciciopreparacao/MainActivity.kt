package com.example.exerciciopreparacao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
