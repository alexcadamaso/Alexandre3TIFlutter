import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final List<String> nomes = [
    'Rogerio Federerico',
    'Rafael Nadalenas',
    'Novaque Dioquovite'
  ];
  final List<String> escola = [
    'Escola Switzerland de Genebra',
    'Escola España de Barcelona',
    'Escola Serbia de Belgrado'
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Fichas de Alunos'),
        ),
        body: ListView.builder(
          itemCount: 3,
          itemBuilder: (BuildContext context, int index) {
            return Ficha(
              imagem: getImageUrl(index),
              nome: nomes[index],
              matricula: Random().nextInt(100000),
              escola: escola[index],
              anoPeriodo: '2023/1',
            );
          },
        ),
      ),
    );
  }

  String getImageUrl(int index) {
    switch (index) {
      case 0:
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/R_federer.jpg/220px-R_federer.jpg';
      case 1:
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Rafa_Nadal_%28Spain%29.jpg/220px-Rafa_Nadal_%28Spain%29.jpg';
      case 2:
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Novak_Djokovic_CU.jpg/394px-Novak_Djokovic_CU.jpg';
      default:
        return '';
    }
  }
}

class Ficha extends StatelessWidget {
  final String imagem;
  final String nome;
  final int matricula;
  final String escola;
  final String anoPeriodo;

  Ficha({
    required this.imagem,
    required this.nome,
    required this.matricula,
    required this.escola,
    required this.anoPeriodo,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
              imagem,
              width: 150,
              height: 150,
            ),
            SizedBox(height: 10),
            Text('Nome: $nome'),
            Text('Matrícula: $matricula'),
            Text('Escola: $escola'),
            Text('Ano/Período: $anoPeriodo'),
          ],
        ),
      ),
    );
  }
}
